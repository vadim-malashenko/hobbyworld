<?php


namespace Hobbyworld;


class Http {

    const METHODS = [
        'GET' => true,
        'POST' => true
    ];
}