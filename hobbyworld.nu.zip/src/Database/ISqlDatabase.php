<?php


namespace Hobbyworld\Database;


interface ISqlDatabase {

}